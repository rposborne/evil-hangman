window.addEventListener('load', function () {
    console.log('Welcome to the crash course!');
    console.log('These messages print when the page is done loading.');

    eop(exampleFunction.bind(null, [1, 4, 5, 3, 2, 8]), 'viz');
});

function exampleFunction(numbers) {
    return numbers.map(function (number) {
        return number * number;
    }).filter(function (number) {
        return (number % 2 == 0);
    }).reduce(function (prev, current) {
        return prev + current;
    }, 0);
}